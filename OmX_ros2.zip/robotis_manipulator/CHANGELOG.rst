^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robotis_manipulator
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2019-02-08)
------------------
* updated the CHANGELOG and version to release binary packages
* modified the package information for release
* added the manipulation API and functions for controlling the manipulator
* made new ROS package
* Contributors: Hye-Jong KIM, Darby Lim, Yong-Ho Na, Ryan Shim, Guilherme de Campos Affonso, Pyo
